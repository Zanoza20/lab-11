var dataTypes = {
  String: "Hello",
  Number: 123,
  Boolean: true,
  Undefined: undefined,
  Null: null
};

console.log(dataTypes);
