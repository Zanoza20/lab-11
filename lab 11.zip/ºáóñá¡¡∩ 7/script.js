var login = prompt("Please enter your login:");
var email = prompt("Please enter your email:");
var password = prompt("Please enter your password:");

console.log("Dear User, your email is " + email + ", your password is " + password);