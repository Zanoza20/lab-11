var isAdult = confirm("Are you an adult?");
console.log(isAdult);
