var secondsInHour = 60 * 60;
var secondsInDay = 24 * secondsInHour;
var secondsInMonth = 30 * secondsInDay;

console.log("Seconds in an hour:", secondsInHour);
console.log("Seconds in a day:", secondsInDay);
console.log("Seconds in a month:", secondsInMonth);