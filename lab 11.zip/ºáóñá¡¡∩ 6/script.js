var firstName = "Влад";
var lastName = "Данилейко";
var group = "КН-321";
var birthYear = 2004;
var isMarried = false;

console.log(typeof firstName, typeof lastName, typeof group);
console.log(birthYear, isMarried);

var nullVar = null;
var undefinedVar = undefined;
console.log(typeof nullVar, typeof undefinedVar);